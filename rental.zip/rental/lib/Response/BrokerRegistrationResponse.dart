class BrokerRegistrationResponse {
  BrokerRegistrationResult? data;
  String? message;
  bool? success;
  int? status;

  BrokerRegistrationResponse(
      {this.data, this.message, this.success, this.status});

  BrokerRegistrationResponse.fromJson(Map<String, dynamic> json) {
    data = json['data'] != null ? new BrokerRegistrationResult.fromJson(json['data']) : null;
    message = json['message'];
    success = json['success'];
    status = json['status'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['message'] = this.message;
    data['success'] = this.success;
    data['status'] = this.status;
    return data;
  }
}

class BrokerRegistrationResult {
  int? id;
  String? fullname;
  String? mobileno;
  String? email;
  String?address;
  String? city;
  String? state;
  String? pincode;
  String? brokerType;
  String? panCard;
  String? password;
  bool? active;

  BrokerRegistrationResult(
      {this.id,
        this.fullname,
        this.mobileno,
        this.email,
        this.address,
        this.city,
        this.state,
        this.pincode,
        this.brokerType,
        this.panCard,
        this.password,
        this.active});

  BrokerRegistrationResult.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    fullname = json['fullname'];
    mobileno = json['mobileno'];
    email = json['email'];
    address=json['address'];
    city = json['city'];
    state = json['state'];
    pincode = json['pincode'];
    brokerType = json['brokerType'];
    panCard = json['panCard'];
    password=json['password'];
    active = json['active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['fullname'] = this.fullname;
    data['mobileno'] = this.mobileno;
    data['email'] = this.email;
    data['address']=this.address;
    data['city'] = this.city;
    data['state'] = this.state;
    data['pincode'] = this.pincode;
    data['brokerType'] = this.brokerType;
    data['panCard'] = this.panCard;
    data['password']=this.password;
    data['active'] = this.active;
    return data;
  }
}