// import 'dart:async';
// import 'package:path/path.dart' as p;
// import 'package:sqflite/sqflite.dart';
//
// //https://github.com/SnippetCoders/flutter_sqlite
// abstract class DB {
//   static Database? _db;
//
//   static final String PRODDUCTID = "PRODDUCTID";
//   static final String PRODUCTNAME = "PRODUCTNAME";
//   static final String CATEGORYID = "CATEGORYID";
//   static final String CATEGORYNAME = "CATEGORYNAME";
//   static final String PRODUCTOLDPRICE = "PRODUCTOLDPRICE";
//   static final String PRODUCTNEWPRICE = "PRODUCTNEWPRICE";
//   static final String PRODUCTSAVEPRICE = "PRODUCTSAVEPRICE";
//   static final String DISCOUNT = "DISCOUNT";
//   static final String TOTALAMOUNT = "TOTALAMOUNT";
//   static final String STATUS = "STATUS";
//   static final String PRODUCT_TOTAL = "productTotal";
//   static final String PRODUCT_PAYABLE_AMT = "productPayableAmt";
//   static final String QUNTITY = "QUNTITY";
//
//   static int get _version => 1;
//
//   static Future<void> init() async {
//     return;
//
//     try {
//       var databasesPath = await getDatabasesPath();
//       String _path = p.join(databasesPath, 'crud.db');
//       _db = await openDatabase(_path, version: _version, onCreate: onCreate);
//     } catch (ex) {
//       print(ex);
//     }
//   }
//
//   static void onCreate(Database db, int version) async {
//     await db.execute(
//         'CREATE TABLE products ('+
//             PRODDUCTID+' INTEGER PRIMARY KEY,'+
//             PRODUCTNAME+' STRING, '+
//             CATEGORYNAME+' STRING, '+
//             CATEGORYID+' INTEGER,'+
//             QUNTITY+' INTEGER,'+
//             PRODUCTOLDPRICE+' REAL,'+
//             PRODUCTNEWPRICE+' REAL,'+
//             PRODUCTSAVEPRICE+' REAL, '+
//             DISCOUNT+' REAL, '+
//             TOTALAMOUNT+' REAL, '+
//             PRODUCT_TOTAL+' REAL, '+
//             PRODUCT_PAYABLE_AMT+' REAL, '+
//             STATUS+' String)');
//     /*await db.execute(
//         'CREATE TABLE product_categories (id INTEGER PRIMARY KEY AUTOINCREMENT, categoryName STRING)');
//     await db.execute(
//         "INSERT INTO product_categories (categoryName) VALUES ('T-Shirt'), ('Shirt'), ('Trouser'),  ('Shoes');");*/
//   }
//
//   static Future<Future<List<Map<String, Object?>>>?> query(String table) async =>
//       _db?.query(table);
//
// /*  static Future<int> insert(String table, Model model) async =>
//       await _db.insert(table, model.toMap());
//
//   static Future<int> update(String table, Model model) async => await _db
//       .update(table, model.toMap(), where: 'id = ?', whereArgs: [model.id]);
//
//   static Future<int> delete(String table, Model model) async =>
//       await _db.delete(table, where: 'id = ?', whereArgs: [model.id]);*/
//
//   static Future<Batch?> batch() async => _db?.batch();
// }
