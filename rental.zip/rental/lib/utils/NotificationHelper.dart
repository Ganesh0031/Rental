//
//
//
// import 'package:awesome_notifications/awesome_notifications.dart';
// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter/foundation.dart';
// import 'package:flutter/material.dart';
//
// class NotificationAwesomeHelper {
//
//   static Future<void> createNotification(RemoteMessage message) async {
//     String? imageUrl = message.data['image'];
//
//         print('Notification Data: ${message.data}');
//     print('Notification Data image: ${message.data['image']}');
//     print('Notification Data image: $imageUrl');
//     print('Notification Data title: ${message.data['title']}');
//     print('Notification Data body: ${message.data['body']}');
//     // Ensure image URL is not null or empty
//     if (imageUrl != null && imageUrl.isNotEmpty) {
//       try {
//         await AwesomeNotifications().createNotification(
//           content: NotificationContent(
//             id: 12324,
//             channelKey: 'basic',
//             title: message.data['title'],
//             body: message.data['body'],
//             bigPicture: imageUrl,
//             notificationLayout: NotificationLayout.BigPicture,
//             fullScreenIntent: true,
//             payload: {"name": "FlutterCampus"},
//             autoDismissible: false,
//           ),
//           actionButtons: [
//             NotificationActionButton(
//               key: "Read",
//               label: "Read",
//             ),
//           ],
//         );
//       } catch (e) {
//         if (kDebugMode) {
//           print('Error setting big picture: $e');
//         }
//       }
//     } else {
//       // Fallback to a simple notification without an image if the image URL is null or empty
//       await AwesomeNotifications().createNotification(
//         content: NotificationContent(
//           id: 12324,
//           channelKey: 'basic',
//           title: message.data['title'],
//           body: message.data['body'],
//           fullScreenIntent: true,
//           payload: {"name": "FlutterCampus"},
//           autoDismissible: false,
//         ),
//         actionButtons: [
//           NotificationActionButton(
//             key: "Read",
//             label: "Read",
//           ),
//         ],
//       );
//     }
//   }
//
//   static void initialize() {
//     FirebaseMessaging.instance.getToken().then((value) {
//       String? token = value;
//       if (kDebugMode) {
//         print("Token : " + token.toString());
//       }
//     });
//
//     AwesomeNotifications().initialize('resource://drawable/ic_launcher', [
//       NotificationChannel(
//         channelGroupKey: 'basic_test',
//         channelKey: 'basic',
//         channelName: 'Basic notifications',
//         channelDescription: 'Notification channel for basic tests',
//         channelShowBadge: true,
//         importance: NotificationImportance.High,
//         enableVibration: true,
//       ),
//     ]);
//
//     FirebaseMessaging.onMessage.listen((RemoteMessage message) {
//       createNotification(message);
//     });
//   }
// }
