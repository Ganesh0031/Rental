// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
//
// class SharePrefsHelper {
//   // static final String LOGIN_MODEL = "LOGIN_MODEL";
//   static final String REG_MODEL = "REG_MODEL";
//   static final String PACKING_MODEL = "PACKING_MODEL";
//   static final String USER_ID = "USER_ID";
//   static final String USER_TYPE = "USER_TYPE";
//   /*static final String USER_OTP = "USER_OTP";
//   static final String USER_OLD_NEW = "USER_OLD_NEW";*/
//   static final String phone_varified = "phone_varified";
//   static final String USER_NAME = "USER_NAME";
//   static final String USER_PHONE = "USER_PHONE";
//
//   static final String ADDRESS1 = "address1";
//   static final String ADDRESS2 = "address2";
//   static final String GSTNO = "gstno";
//   static final String STATENAME = "statename";
//   static final String CITYNAME = "cityname";
//   static final String WHATSAPNO = "whatsappphoneno";
//   static final String SHOP_IMAGE = "shopimage";
//
//
//
//   late BuildContext context;
//   static late SharePrefsHelper instance;
//
//   SharePrefsHelper(BuildContext context) {
//     this.context = context;
//   }
//
//   static SharePrefsHelper getInstance(BuildContext context) {
//     if (instance == null) {
//       instance = new SharePrefsHelper(context);
//     }
//     return instance;
//   }
//
//   Future<void> clearAll() async {
//     SharedPreferences preferences = await SharedPreferences.getInstance();
//     preferences.clear();
//   }
//
//   Future<void> clearKey(String prefsKey) async {
//     SharedPreferences preferences = await SharedPreferences.getInstance();
//     preferences.remove(prefsKey);
//   }
//
//   Future<void> saveStringValue(String prefsKey, String value) async {
//     SharedPreferences preferences = await SharedPreferences.getInstance();
//     preferences.setString(prefsKey, value);
//   }
//
//   Future<void> saveBoolValue(String prefsKey, bool value) async {
//     SharedPreferences preferences = await SharedPreferences.getInstance();
//     preferences.setBool(prefsKey, value);
//   }
//
//   Future<void> saveIntValue(String prefsKey, int value) async {
//     SharedPreferences preferences = await SharedPreferences.getInstance();
//     preferences.setInt(prefsKey, value);
//   }
//
//   Future<String?> getStringValue(String prefsKey) async {
//     SharedPreferences preferences = await SharedPreferences.getInstance();
//     return preferences.getString(prefsKey);
//   }
//
//   Future<bool?> getBoolValue(String prefsKey) async {
//     SharedPreferences preferences = await SharedPreferences.getInstance();
//     return preferences.getBool(prefsKey);
//   }
//
//   Future<int?> getIntValue(String prefsKey) async {
//     SharedPreferences preferences = await SharedPreferences.getInstance();
//     return preferences.getInt(prefsKey);
//   }
//
//   // Future<void> saveLoginModel(MobileOtpResponse loginResponse) async {
//   //   try {
//   //     String jsonString = gson.encode(loginResponse.toJson());
//   //     saveStringValue(LOGIN_MODEL, jsonString);
//   //   } catch (e) {
//   //     print(e);
//   //   }
//   // }
//   //
//   // Future<MobileOtpResponse> getLoginModel() async {
//   //   String jsonString = "";
//   //   MobileOtpResponse userModel = new MobileOtpResponse();
//   //   try {
//   //     jsonString = await getStringValue(LOGIN_MODEL);
//   //
//   //     if (Utilities.isEmpty(jsonString)) {
//   //       return null;
//   //     }
//   //     var model = gsonDecode(jsonString);
//   //     userModel = MobileOtpResponse.fromJson(model);
//   //   } catch (e) {
//   //     print(e);
//   //   }
//   //   return userModel;
//   // }
//   Future<void> saveRegModel(String jsonString) async {
//     try {
//       saveStringValue(REG_MODEL, jsonString);
//     } catch (e) {
//       print(e);
//     }
//   }
//  /* Future<void> saveproductpackingModel(packingSizeandcostResponse packingSizeandcost) async {
//     try {
//       String jsonString = gson.encode(packingSizeandcost.toJson());
//       saveStringValue(PACKING_MODEL, jsonString);
//     } catch (e) {
//       print(e);
//     }
//   }
//   Future<Data> getRegModel() async {
//     String jsonString = "";
//     Data regModel = new Data();
//     try {
//       jsonString = await getStringValue(REG_MODEL);
//
//       if (Utilities.isEmpty(jsonString)) {
//         return null;
//       }
//       var model = gsonDecode(jsonString);
//       regModel = Data.fromJson(model);
//     } catch (e) {
//       print(e);
//     }
//     return regModel;
//   }*/
//   /*Future<packingSizeandcostResponse> getPackingModel() async {
//     String jsonString = "";
//     packingSizeandcostResponse packingModel = new packingSizeandcostResponse();
//     try {
//       jsonString = await getStringValue(REG_MODEL);
//
//       if (Utilities.isEmpty(jsonString)) {
//         return null;
//       }
//       var model = gsonDecode(jsonString);
//       packingModel = packingSizeandcostResponse.fromJson(model);
//     } catch (e) {
//       print(e);
//     }
//     return packingModel;
//   }*/
// }
