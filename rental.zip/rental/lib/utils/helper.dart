import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Helper {
  static double getScreenWidth(BuildContext context) {
    return MediaQuery.of(context).size.width;
  }

  static double getScreenHeight(BuildContext context) {
    return MediaQuery.of(context).size.height;
  }

  static String getAssetName(String fileName, String type) {
    return "assets/images/$type/$fileName";
  }

  static TextTheme getTheme(BuildContext context) {
    return Theme.of(context).textTheme;
  }

  String getCurrentDate() {
     DateTime now = DateTime.now();
     DateFormat formatter = new DateFormat("yyyy-MM-dd");
     String formatted = formatter.format(now);
    return formatted;
  }
}
