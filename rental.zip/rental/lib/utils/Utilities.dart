//import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:toast/toast.dart';

class Utilities {

  static late String userId;
  static late String userType;
  static late String userName;
  static late String userPhone;
  static late String phoneVarified;
  static late String profileImage;




  static bool isListEmpty(List<dynamic> list) {
    if (list.length == 0) {
      return true;
    } else {
      return false;
    }
  }

  static bool isEmpty(String string) {
    if (string.isEmpty || string.trim().isEmpty) {
      return true;
    } else {
      return false;
    }
  }

  static bool isIntEmpty(int string) {
    if (string == null) {
      return true;
    } else {
      return false;
    }
  }

  static void showSmallToast(BuildContext context, String message) {
    Toast.show(message,
        duration: Toast.lengthShort,
        gravity: Toast.center,
        backgroundColor: Colors.grey[700]!);
  }

  // static void showLongToast(BuildContext context, String message) {
  //
  //   Toast.show(message,
  //       duration: Toast.lengthShort,
  //       gravity: Toast.center,
  //       backgroundColor: Colors.grey[700]!);
  // }
  static void showLongToast(BuildContext context, String message) {
    Toast.show(
      message,
      duration: Toast.lengthLong,
      gravity: Toast.bottom,
    );
  }

  static String capitalise(String string) {
    String text = "";
    if (!Utilities.isEmpty(string)) {
      text = string[0].toUpperCase() + string.substring(1);
    }
    return text;
  }

  static String removeStringNull(String string) {
    if (string == null) {
      return "";
    }
    return string;
  }

  static int removeIntNull(int string) {
    if (string == null) {
      return 0;
    }
    return string;
  }

/*static Future<String> getToken(FirebaseMessaging firebaseMessaging) async {
    return await firebaseMessaging.getToken();
  }*/

  static String stripHtmlIfNeeded(String text) {
    return text.replaceAll(RegExp(r'<[^>]*>|&[^;]+;'), '');
  }

  static String removeAllHtmlTags(String htmlText) {
    RegExp exp = RegExp(
        r"<[^>]*>",
        multiLine: true,
        caseSensitive: true
    );

    return htmlText.replaceAll(exp, '');
  }

}
