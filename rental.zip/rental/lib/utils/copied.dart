// import 'package:firebase_messaging/firebase_messaging.dart';
// import 'package:flutter/material.dart';
// import 'package:morya_tools/Presenter/CountryCodePresenter.dart';
// import 'package:morya_tools/Presenter/OtpPresenter.dart';
// import 'package:morya_tools/Responses/CountryCodeResponse.dart';
// import 'package:morya_tools/Responses/OtpRespose.dart';
// import 'package:morya_tools/Screens/Home/HomeScreen.dart';
// import 'package:morya_tools/Screens/LoginUser.dart';
// import 'package:morya_tools/Screens/OtpVarification.dart';
// import 'package:morya_tools/Screens/Registration/UserRegistration.dart';
// import 'package:morya_tools/utils/Constants.dart';
// import 'package:morya_tools/utils/SharePrefsHelper.dart';
// import 'package:morya_tools/utils/Utilities.dart';
// import 'package:morya_tools/utils/helper.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:toast/toast.dart';
//
// class PhoneVarification extends StatefulWidget {
//   @override
//   _PhoneVarificationState createState() => _PhoneVarificationState();
// }
//
// class _PhoneVarificationState extends State<PhoneVarification>
//     implements OtpView ,CountryCodeView{
//   var mobileController = new TextEditingController();
//
//   bool isLoading = false;
//   late SharedPreferences prefsdata;
//   late var otp;
//   late OtpePresenter otpePresenter;
//   var _otpForm = GlobalKey<FormState>();
//
//
//   String countrycode="91";
//   String countryname="India";
//   late CountryCodePresenter codePresenter;
//
//   List<CountryCodeResult>countryCodeList=[];
//
//   @override
//   void initState() {
//     otpePresenter = new OtpePresenter(this);
//     codePresenter = new CountryCodePresenter(this);
//     codePresenter.getCountryCode();
//     initialize();
//     _initializeData();
//   }
//
//   void initialize() {
//     FirebaseMessaging.instance.getToken().then((value) {
//       String? token = value;
//       print("Tokennnnnnnnnnn   ${token}");
//     });
//   }
//
//   Future<void> _initializeData() async {
//     prefsdata = await SharedPreferences.getInstance();
//     String? value = await getPref(SharePrefsHelper.phone_varified);
//     print('tushar $value');
//
//
//     Utilities.phoneVarified = value.toString();
//     if (value == 'true') {
//       Navigator.pushAndRemoveUntil(
//         context,
//         MaterialPageRoute(
//           builder: (context) => LoginUser(),
//         ),
//             (route) => false,
//       );
//     } else if (value == '1') {
//       Navigator.pushAndRemoveUntil(
//         context,
//         MaterialPageRoute(
//           builder: (context) => Home(),
//         ),
//             (route) => false,
//       );
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     ToastContext().init(context);
//     /*  TextStyle textStyle = Theme.of(context).textTheme.title;
//     TextStyle textStyle1 = Theme.of(context).textTheme.subtitle1;*/
//     return Scaffold(
//       appBar: AppBar(
//         // title: Text("M S Industries"),
//         // backgroundColor: Colors.indigo[900],
//         // centerTitle: true,
//         title: Image(
//           fit: BoxFit.fill,
//           image: AssetImage(
//             Helper.getAssetName("msi_appbar_small.jpeg", "real"),
//           ),
//         ),
//         backgroundColor: Colors.indigo[900],
//
//       ),
//       backgroundColor: Colors.indigo[900],
//       body: Stack(
//         children: [
//           _OtpBody(context),
//           isLoading ? Center(child: CircularProgressIndicator()) : Container()
//         ],
//       ),
//     );
//   }
//
//   _OtpBody(BuildContext context) {
//     /* TextStyle textStyle = Theme.of(context).textTheme.title;
//     TextStyle textStyle1 = Theme.of(context).textTheme.subtitle1;*/
//     return ListView(
//       children: [
//         Container(
//           margin: EdgeInsets.only(top: 10.0), // Set only the top margin
//           width: 100.0,
//           height: 100.0,
//           child: Image(
//               image: AssetImage(
//                   Helper.getAssetName("ms.jpg", "real"))),
//         ),
//         SizedBox(
//           height: 10.0,
//         ),
//
//         Center(
//           child: Text(
//               "Get Started",
//               style: TextStyle(
//                   color: Colors.white )
//           ),
//         ),
//         SizedBox(
//           height: 10.0,
//         ),
//         Container(
//           margin: EdgeInsets.all(10.0),
//           child: Column(
//             children: [
//               Text(
//                 "Enter Your phone Number & we will send an otp to continue.",
//                 style: TextStyle(
//                     color: Colors.white ),
//                 textAlign: TextAlign.center,
//               ),
//             ],
//           ),
//         ),
//         SizedBox(
//           height: 20.0,
//         ),
//         Column(
//           children: [
//
//
//             Padding(
//               padding: const EdgeInsets.only(top: 5.0, left: 15.0, right: 15.0),
//               child: GestureDetector(
//                 onTap: () {
//                   showAlertCountryCodeDialog(context,"");
//                 },
//                 child: Container(
//                   width: double.infinity,
//                   padding: const EdgeInsets.all(7.0),
//                   decoration: BoxDecoration(
//                       borderRadius: BorderRadius.all(Radius.circular(10.0)),
//                       border: Border.all(color: MyColors.primaryColor, width: 1)),
//                   child: RichText(
//                     text: TextSpan(
//                       children: [
//                         WidgetSpan(
//                           alignment: PlaceholderAlignment.middle,
//                           child: Padding(
//                             padding: const EdgeInsets.all(10.0),
//                             child: Icon(
//                               Icons.location_pin,
//                               color: Colors.black26,
//                             ),
//                           ),
//                         ),
//                         WidgetSpan(
//                           alignment: PlaceholderAlignment.middle,
//                           child: Text(
//                             "+ $countrycode - $countryname",
//                             style: TextStyle(color: Colors.white, fontSize: 18.0),
//                           ),
//                         ),
//                         /*TextSpan(text: 'By Michael'),*/
//                       ],
//                     ),
//                   ),
//                 ),
//               ),
//             ),
//             SizedBox(
//               height: 5,
//             ),
//             Padding(
//               padding: const EdgeInsets.only(top: 5.0, left: 15.0, right: 15.0),
//               child: TextField(
//                 autocorrect: true,
//                 keyboardType: TextInputType.number,
//                 textInputAction: TextInputAction.next,
//                 maxLength: 10,
//                 buildCounter: (BuildContext context,
//                     {required int currentLength, required int? maxLength, required bool isFocused}) =>
//                 null,
//                 decoration: InputDecoration(
//                   hintText: 'Enter Mobile No.',
//                   prefixIcon: Padding(
//                       padding: const EdgeInsets.all(10.0),
//                       child: Icon(
//                         Icons.phone_android,
//                         color: Colors.black26,
//                       )),
//                   // prefixIcon: Icon(Icons.person_rounded),
//                   hintStyle: TextStyle(color: Colors.black26),
//                   filled: true,
//                   fillColor: Colors.white70,
//                   enabledBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.all(Radius.circular(12.0)),
//                     borderSide: BorderSide(color: MyColors.primaryColor, width: 1),
//                   ),
//                   focusedBorder: OutlineInputBorder(
//                     borderRadius: BorderRadius.all(Radius.circular(10.0)),
//                     borderSide: BorderSide(color: Colors.black26, width: 1),
//                   ),
//                 ),
//                 controller: mobileController,
//               ),
//             ),
//           ],
//         ),
//         SizedBox(
//           height: 30.0,
//         ),
//         Container(
//           margin: EdgeInsets.only(right: 50.0, left: 50.0),
//           child: ElevatedButton(
//             onPressed: () {
//               setState(() {
//                 String mobile = mobileController.text.toString();
//                 if (mobile.length==10) {
//                   // print("mobile lengthi on submit === ${mobile} === $countrycode");
//                   // String fullnumber = '+$countrycode$mobile';
//                   String fullnumber = '$mobile';
//                   print("mobile length on submit === $fullnumber ==== ${fullnumber.length}");
//                   print(Helper().getCurrentDate());
//                   otpePresenter.getOtp(fullnumber);
//                   /* Navigator.of(context).push(MaterialPageRoute(
//                       builder: (context) => OtpVarification()));*/
//                 }else{
//                   Utilities.showLongToast(context, 'Invalid Mobile Number.');
//                 }
//
//               });
//             },
//             child: Text(
//               "Submit",
//               style: TextStyle(
//                 fontSize: 20.0,
//               ),
//             ),
//             style: ElevatedButton.styleFrom(
//               //backgroundColor: Theme.of(context).colorScheme.secondary,
//               backgroundColor: MyColors.primaryColor,
//               minimumSize: Size(double.infinity, 50.0),
//             ),
//           ),
//         ),
//       ],
//     );
//   }
//
//   @override
//   void hideLoading() {
//     if (mounted) {
//       setState(() {
//         isLoading = false;
//       });
//     }
//   }
//
//   @override
//   void showError(String msg) {
//     Utilities.showLongToast(context, msg);
//   }
//
//   @override
//   void showLoading() {
//     if (mounted) {
//       setState(() {
//         isLoading = true;
//       });
//     }
//   }
//
//   @override
//   void showOtpResponse(OtpResult? response) {
//
//     String? id=response!.id;
//     int? otp=response!.otp;
//
//     print('Phone varification : ' + id.toString());
//
//     if(id!=""){
//       print('Phone varification : ' + otp.toString());
//       Navigator.of(context).push(MaterialPageRoute(builder: (context) => OtpVarification(otp.toString(),'old',id.toString())));
//       // Navigator.of(context).push(MaterialPageRoute(builder: (context) => UserRegistration()));
//     }else{
//       Navigator.of(context)
//           .push(MaterialPageRoute(builder: (context) => OtpVarification(otp.toString(),'new',"")));
//     }
//
//   }
//
//   Future<String?> getPref(String key) async {
//     SharePrefsHelper prefs = await SharePrefsHelper.getInstance(context);
//     return prefs.getStringValue(key);
//   }
//
//
//
//   @override
//   void showCountryCodeResponse(CountryCodeResponse response) {
//     // TODO: implement showCountryCodeResponse
//
//     countryCodeList.clear();
//     countryCodeList=response.result!;
//   }
//
// //get country code list in alert dialogue
//   void showAlertCountryCodeDialog(BuildContext context, String str) {
//     List<CountryCodeResult> filteredCountryList = List.from(countryCodeList);
//
//     // Function to handle the onTap logic
//     Function onTapLogic = (CountryCodeResult countryCodeResult) {
//       setState(() {
//         countrycode = countryCodeResult.countryCode ?? '';
//         countryname = countryCodeResult.countryName ?? '';
//       });
//       Navigator.pop(context);
//     };
//
//     // Generating list items for country codes
//     List<Widget> generateListItems(List<CountryCodeResult> list) {
//       return list.map((CountryCodeResult countryCodeResult) {
//         return GestureDetector(
//           onTap: () => onTapLogic(countryCodeResult),
//           child: Card(
//             child: Padding(
//               padding: EdgeInsets.all(5.0),
//               child: Row(
//                 children: [
//                   Expanded(
//                     child: Text(
//                       '${countryCodeResult.countryCode ?? ''} ${countryCodeResult.countryName ?? ''}',
//                       style: const TextStyle(color: Colors.black, fontSize: 15.0),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         );
//       }).toList();
//     }
//
//     // Show the dialog with search functionality
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return StatefulBuilder(
//           builder: (context, setState) {
//             return AlertDialog(
//               title: Text('Select Country'),
//               content: Column(
//                 mainAxisSize: MainAxisSize.min,
//                 children: [
//                   TextField(
//                     onChanged: (value) {
//                       setState(() {
//                         filteredCountryList = countryCodeList
//                             .where((country) => country.countryName?.toLowerCase().contains(value.toLowerCase()) ?? false)
//                             .toList();
//                       });
//                     },
//                     decoration: InputDecoration(
//                       hintText: 'Search country...',
//                       prefixIcon: Icon(Icons.search),
//                     ),
//                   ),
//                   SizedBox(height: 10),
//                   Expanded(
//                     child: Container(
//                       height: MediaQuery.of(context).size.height * 0.6,
//                       child: SingleChildScrollView(
//                         child: Column(
//                           mainAxisSize: MainAxisSize.min,
//                           children: generateListItems(filteredCountryList),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             );
//           },
//         );
//       },
//     ).then((value) {
//       // Perform any necessary operations after the dialog is dismissed
//     });
//   }
// }
//
//
//
// // sharepreaference general code
//
// // Future<void> getAndPrintSharedPreferencesValue() async {
// //   SharedPreferences prefs = await SharedPreferences.getInstance();
// //   String? value = prefs.getString('phone_verified_key');
// //   print('Phone Verified: $value');
// // }