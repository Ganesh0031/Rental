import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rental/utils/Constants.dart';
import '../Controller/BrokerRegistrationController.dart';

class BrokerRegistrationScreen extends StatelessWidget {
  final BrokerRegistrationController _ctrl =
  Get.put(BrokerRegistrationController());

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      return Stack(
        children: [
          Scaffold(
            appBar: AppBar(
                title: const Text("Broker Registration",
                    style: TextStyle(color: Colors.white)),
                backgroundColor: MyColors.lightblue),
            body: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Form(
                key: _ctrl.formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _input("Full Name",
                        save: (v) => _ctrl.fullName.value = v!,
                        validate: (v) =>
                        v!.isEmpty ? "Required" : null),
                    _gap(),

                    _input("Mobile Number",
                        type: TextInputType.phone,
                        save: (v) => _ctrl.mobileno.value = v!,
                        validate: (v) =>
                        v!.length == 10 ? null : "Enter 10 digit mobile"),
                    _gap(),

                    _input("Email",
                        type: TextInputType.emailAddress,
                        save: (v) => _ctrl.email.value = v!,
                        validate: (v) =>
                        v!.contains('@') ? null : "Invalid email"),
                    _gap(),

                    _input("Address",
                        save: (v) => _ctrl.address.value = v!),
                    _gap(),

                    _input("City",
                        save: (v) => _ctrl.city.value = v!),
                    _gap(),

                    _input("State",
                        save: (v) => _ctrl.state.value = v!),
                    _gap(),

                    _input("PIN Code",
                        type: TextInputType.number,
                        save: (v) => _ctrl.pincode.value = v!,
                        validate: (v) =>
                        RegExp(r'^\d{6}$').hasMatch(v!)
                            ? null
                            : "Invalid PIN"),
                    _gap(),

                    DropdownButtonFormField<String>(
                      decoration: const InputDecoration(
                        labelText: "Broker Type",
                        border: OutlineInputBorder(),
                      ),
                      items: [
                        "Residential",
                        "Commercial",
                        "Land",
                        "Rentals"
                      ]
                          .map((e) =>
                          DropdownMenuItem(value: e, child: Text(e)))
                          .toList(),
                      onChanged: (v) => _ctrl.brokerType.value = v!,
                      validator: (v) =>
                      (v == null) ? "Select broker type" : null,
                    ),
                    _gap(),

                    _input("PAN Number",
                        save: (v) => _ctrl.panCard.value = v!,
                        validate: (v) =>
                        v!.isEmpty ? "Required" : null),
                    _gap(),

                    // ✅ Password Field
                    _input("Password",
                        type: TextInputType.text,
                        isPassword: true,
                        save: (v) => _ctrl.password.value = v!,
                        validate: (v) =>
                        v!.length >= 6 ? null : "Min 6 characters"),
                    _gap(),

                    // ✅ Confirm Password Field
                    _input("Confirm Password",
                        isPassword: true,
                        save: (v) => _ctrl.confirmPassword.value = v!,
                        validate: (v) =>
                        v!.isEmpty ? "Required" : null),
                    const SizedBox(height: 25),

                    Center(
                      child: SizedBox(
                        width: 180,
                        child: ElevatedButton(
                          onPressed: _ctrl.submitRegistration,
                          style: ElevatedButton.styleFrom(
                            padding: const EdgeInsets.all(14),
                            backgroundColor: MyColors.lightblue,
                          ),
                          child: const Text("Register",
                              style: TextStyle(
                                  color: Colors.white, fontSize: 16)),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          if (_ctrl.isLoading.value)
            Container(
              color: Colors.black45,
              child: const Center(child: CircularProgressIndicator()),
            ),
        ],
      );
    });
  }

  Widget _input(String label,
      {TextInputType type = TextInputType.text,
        bool isPassword = false,
        String? Function(String?)? validate,
        void Function(String?)? save}) {
    return TextFormField(
      keyboardType: type,
      obscureText: isPassword,
      validator: validate,
      onSaved: save,
      decoration: InputDecoration(
          labelText: label,
          border: const OutlineInputBorder()),
    );
  }

  SizedBox _gap() => const SizedBox(height: 18);
}
