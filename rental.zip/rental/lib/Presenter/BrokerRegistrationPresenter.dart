import 'dart:convert';
import 'package:http/http.dart';
import '../Repositories/RestAdapterRepository.dart';
import '../Response/BrokerRegistrationResponse.dart';
import '../views/MVPView.dart';

abstract class BrokerRegistrationGetView extends MVPView {
  void showBrokerRegistrationDataGetResponse(BrokerRegistrationResponse response);
}

abstract class BrokerRegistrationGetOps {
  void getBrokerRegistrationData(String fullname,  String mobileno,
   String email,
   String address,
   String city,
   String state,
   String pincode,
   String brokerType,
   String panCard,
      String password);
  void onBrokerRegistrationDataReceived(BrokerRegistrationResponse response);
}


class BrokerRegistrationPresenter implements BrokerRegistrationGetOps {
  BrokerRegistrationGetView brokerRegistrationGetView;
  late RestAdapterRepository _adapterRepository;

  BrokerRegistrationPresenter(this.brokerRegistrationGetView) {
    _adapterRepository = RestAdapterRepository();
  }

  @override
  void getBrokerRegistrationData(String fullname,  String mobileno,
      String email,
      String address,
      String city,
      String state,
      String pincode,
      String brokerType,
      String panCard ,
      String password) {
    var params = {
      'fullname': fullname,
      'mobileno': mobileno,
      'email':email,
      'address':address,
      'city':city,
      'state':state,
      'pincode':pincode,
      'brokerType':brokerType,
      'panCard':panCard,
      'password':password
    };

    brokerRegistrationGetView.showLoading();

    _adapterRepository
        .postRequest("broker/addBroker",params)
        .then((res) {
      Response response = res as Response;
      print(response.statusCode);
      print("Response of BrokerRegistration API in presenter: ${response.body}");

      if (response.statusCode == 200) {
        BrokerRegistrationResponse brokerRegistrationResponse =
        BrokerRegistrationResponse.fromJson(jsonDecode(response.body));

        print("BrokerRegistration data params: $params");
        print("BrokerRegistration data API Response: $BrokerRegistrationResponse");
        onBrokerRegistrationDataReceived( BrokerRegistrationResponse as BrokerRegistrationResponse);
      } else {
        brokerRegistrationGetView.hideLoading();
      }
    }).catchError((onError) {
      print(onError.toString());
      brokerRegistrationGetView.hideLoading();
    });
  }

  @override
  void onBrokerRegistrationDataReceived(BrokerRegistrationResponse response) {
    brokerRegistrationGetView.hideLoading();
    brokerRegistrationGetView.showBrokerRegistrationDataGetResponse(response);
  }


}
