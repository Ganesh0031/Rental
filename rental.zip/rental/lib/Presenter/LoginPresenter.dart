import 'dart:convert';
import 'package:http/http.dart';
import '../Repositories/RestAdapterRepository.dart';
import '../Response/LoginResponse.dart';
import '../views/MVPView.dart';

abstract class LoginGetView extends MVPView {
  void showLoginDataGetResponse(LoginResponse response);
}

abstract class LoginGetOps {
  void getLoginData(String mobile, String password);
  void onLoginDataReceived(LoginResponse response);
}

class LoginPresenter implements LoginGetOps {
  LoginGetView loginGetView;
  late RestAdapterRepository _adapterRepository;

  LoginPresenter(this.loginGetView) {
    _adapterRepository = RestAdapterRepository();
  }

  @override
  void getLoginData(String mobile, String password) {
    var params = {
      'mobile': mobile,
      'password': password,
    };

    loginGetView.showLoading();

    _adapterRepository.getRequest("broker/login", queryParams: params).then((res) {
      if (res == null) {
        loginGetView.hideLoading();
        loginGetView.showError("No response from server");
        return;
      }

      print("Response of Login API in presenter: ${res.body}");

      if (res.statusCode == 200) {
        final json = jsonDecode(res.body);
        LoginResponse loginResponse = LoginResponse.fromJson(json);

        print("✅ Login data params: $params");
        print("✅ Login API Response: ${loginResponse.message}");

        onLoginDataReceived(loginResponse);
      } else {
        loginGetView.hideLoading();
        loginGetView.showError("Invalid credentials or server error");
      }
    }).catchError((error) {
      loginGetView.hideLoading();
      loginGetView.showError("Error: $error");
    });
  }

  @override
  void onLoginDataReceived(LoginResponse response) {
    loginGetView.hideLoading();
    loginGetView.showLoginDataGetResponse(response);
  }
}
