import 'package:flutter/material.dart';
import 'package:get/get_navigation/src/root/get_material_app.dart';
import  'Screen/HomeScreen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Real Estate App',
      home: HomeScreen(),  // your first screen
    );
  }
}
