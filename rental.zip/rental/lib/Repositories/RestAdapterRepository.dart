import 'dart:convert';
import 'package:http/http.dart' as http;

class RestAdapterRepository {
  static const String BASE_URL = "http://192.168.29.166:8080/api/"; // Emulator support

  final Map<String, String> defaultHeaders = {
    'Accept': 'application/json',
    'Content-Type': 'application/json',
  };

  Future<http.Response?> getRequest(String endpoint, {Map<String, dynamic>? queryParams}) async {
    try {
      Uri uri = Uri.parse(BASE_URL + endpoint)
          .replace(queryParameters: queryParams);

      print("📡 GET URL --> $uri");

      final response = await http.get(uri, headers: defaultHeaders);

      print("✅ Status: ${response.statusCode}");
      print("📦 Response: ${response.body}");
      return response;
    } catch (e) {
      print("❌ GET Error: $e");
      return null;
    }
  }


  Future<http.Response?> postRequest(String endpoint, dynamic body) async {
    try {
      Uri uri = Uri.parse(BASE_URL + endpoint);

      print("📡 POST URL --> $uri");
      print("📨 Body --> $body");

      final response = await http.post(
        uri,
        headers: defaultHeaders,
        body: jsonEncode(body),
      );

      print("✅ Status: ${response.statusCode}");
      print("📦 Response: ${response.body}");
      return response;
    } catch (e) {
      print("❌ POST Error: $e");
      return null;
    }
  }

  Future<http.Response?> putRequest(String endpoint, dynamic body) async {
    try {
      Uri uri = Uri.parse(BASE_URL + endpoint);

      print("✏️ PUT URL --> $uri");
      print("📨 Body --> $body");

      final response = await http.put(
        uri,
        headers: defaultHeaders,
        body: jsonEncode(body),
      );

      print("✅ Status: ${response.statusCode}");
      print("📦 Response: ${response.body}");
      return response;
    } catch (e) {
      print("❌ PUT Error: $e");
      return null;
    }
  }

  Future<http.Response?> deleteRequest(String endpoint) async {
    try {
      Uri uri = Uri.parse(BASE_URL + endpoint);

      print("🗑 DELETE URL --> $uri");

      final response = await http.delete(uri, headers: defaultHeaders);

      print("✅ Status: ${response.statusCode}");
      print("📦 Response: ${response.body}");
      return response;
    } catch (e) {
      print("❌ DELETE Error: $e");
      return null;
    }
  }
}
