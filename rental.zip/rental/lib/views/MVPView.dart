abstract class MVPView {
  void showLoading();
  void hideLoading();
  void showError(String msg);
}
