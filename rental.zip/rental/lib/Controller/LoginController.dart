import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../Presenter/LoginPresenter.dart';
import '../Response/LoginResponse.dart';
import '../views/MVPView.dart';
import '../Screen/HomeScreen.dart';

class LoginController extends GetxController implements LoginGetView {
  final formKey = GlobalKey<FormState>();
  late LoginPresenter presenter;

  final mobile = ''.obs;
  final password = ''.obs;

  var isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    presenter = LoginPresenter(this);
  }

  void submitLogin() {
    if (!formKey.currentState!.validate()) return;

    presenter.getLoginData(
      mobile.value.trim(),
      password.value.trim(),
    );
  }

  @override
  void showLoading() => isLoading.value = true;

  @override
  void hideLoading() => isLoading.value = false;

  @override
  void showError(String message, {String title = "Error"}) {
    Get.snackbar(
      title,
      message,
      snackPosition: SnackPosition.BOTTOM,
      backgroundColor: Colors.red.withOpacity(0.8),
      colorText: Colors.white,
    );
  }

  @override
  void showLoginDataGetResponse(LoginResponse response) {
    hideLoading();

    if (response.data == true) {
      Get.snackbar(
        "Success",
        response.message ?? "Login Successful ✅",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green.withOpacity(0.8),
        colorText: Colors.white,
      );
      Future.delayed(const Duration(seconds: 1), () {
        Get.offAll(() => HomeScreen());
      });
    } else {
      showError(response.message ?? "Invalid Mobile or Password");
    }
  }
}
