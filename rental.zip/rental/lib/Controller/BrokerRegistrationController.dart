import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../Presenter/BrokerRegistrationPresenter.dart';
import '../Response/BrokerRegistrationResponse.dart';
import '../views/MVPView.dart';

class BrokerRegistrationController extends GetxController
    implements BrokerRegistrationGetView {

  final formKey = GlobalKey<FormState>();

  late BrokerRegistrationPresenter presenter;

  // Observable fields ✅
  final fullName = ''.obs;
  final mobileno = ''.obs;
  final email = ''.obs;
  final address = ''.obs;
  final city = ''.obs;
  final state = ''.obs;
  final pincode = ''.obs;
  final brokerType = ''.obs;
  final panCard = ''.obs;
  final password = ''.obs;
  final confirmPassword = ''.obs;

  var isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    presenter = BrokerRegistrationPresenter(this);
  }

  void submitRegistration() {
    if (!formKey.currentState!.validate()) return;

    formKey.currentState!.save();
    if (password.value != confirmPassword.value) {
      showError("Passwords do not match!");
      return;
    }

    presenter.getBrokerRegistrationData(
      fullName.value,
      mobileno.value,
      email.value,
      address.value,
      city.value,
      state.value,
      pincode.value,
      brokerType.value,
      panCard.value,
      password.value,
    );
  }

  @override
  void showLoading() => isLoading.value = true;

  @override
  void hideLoading() => isLoading.value = false;

  @override
  void showError(String message, {String title = "Error"}) {
    Get.snackbar(title, message, snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.red.withOpacity(0.7), colorText: Colors.white);
  }

  @override
  void showBrokerRegistrationDataGetResponse(
      BrokerRegistrationResponse response) {
    hideLoading();
    Get.snackbar("Success",
        response.message ?? "Broker Registered Successfully!",
        snackPosition: SnackPosition.BOTTOM,
        backgroundColor: Colors.green, colorText: Colors.white);
  }
}
