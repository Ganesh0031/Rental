import 'package:get/get.dart';
import 'package:flutter/material.dart';
import 'package:rental/Screen/LoginScreen.dart';

class HomeController extends GetxController {
  final List<HomeItem> items = [
    HomeItem(title: "Broker", icon: Icons.person_search),
    HomeItem(title: "Sell Property", icon: Icons.sell),
    HomeItem(title: "Buy / Rent", icon: Icons.home_work),
    HomeItem(title: "Post for Rent", icon: Icons.post_add),
  ];

  void onItemTap(int index) {
    switch(index) {
      case 0:
        Get.to(() =>LoginScreen());
        break;
      case 1:
        Get.to(() => ());
        break;
      case 2:
        Get.to(() => ());
        break;
      case 3:
        Get.to(() => ());
        break;
      default:
        break;
    }
  }
}


class HomeItem {
  final String title;
  final IconData icon;

  HomeItem({required this.title, required this.icon});
}
