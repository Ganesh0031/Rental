package com.example.Rental;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentalApplicationTests {

	@Test
	void contextLoads() {
	}

}
