package com.example.Rental.Services;

import com.example.Rental.Entity.BrokerRegistration;
import com.example.Rental.Repository.BrokerRegistrationRepository;
import jakarta.persistence.Entity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
@Service
public class BrokerRegistrationServices {
    @Autowired
    private BrokerRegistrationRepository brokerRegistrationRepository;
    public BrokerRegistration add(BrokerRegistration brokerRegistration) {
        brokerRegistration.setActive(true);
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        String encryptedPassword = encoder.encode(brokerRegistration.getPassword());
        brokerRegistration.setPassword(encryptedPassword);
        return brokerRegistrationRepository.save(brokerRegistration);
    }
    public boolean login(String mobileNo, String rawPassword) {
        BrokerRegistration broker = brokerRegistrationRepository.findByMobileno(mobileNo);
        if (broker == null) {
            return false;
        }
        BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
        return encoder.matches(rawPassword, broker.getPassword());
    }
}
