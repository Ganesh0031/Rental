package com.example.Rental.Controller;

import com.example.Rental.Dto.ResponseDTO;
import com.example.Rental.Entity.BrokerRegistration;
import com.example.Rental.Services.BrokerRegistrationServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RequestMapping("/api/broker")
@RestController
public class BrokerRegistrationController {
    @Autowired
    private BrokerRegistrationServices brokerRegistrationServices;
    @PostMapping("/addBroker")
    public ResponseDTO add(@RequestBody BrokerRegistration brokerRegistration){
        ResponseDTO response=new ResponseDTO();
        try {
            response.data=brokerRegistrationServices.add(brokerRegistration);
            response.message="Success";
            response.success=true;
            response.status=200l;
        }catch (Exception e){
            response.message="UnSucess";
            response.success=false;
            response.status=500l;
        }
        return response;
    }
    @GetMapping("/login")
    public ResponseDTO matchPass(@RequestParam String mobile ,@RequestParam String password ){
        ResponseDTO response=new ResponseDTO();
        try {
            response.data=brokerRegistrationServices.login(mobile,password);
            response.message="Success";
            response.success=true;
            response.status=200l;
        }catch (Exception e){
            response.message="UnSucess";
            response.success=false;
            response.status=500l;
        }
        return response;
    }

        }