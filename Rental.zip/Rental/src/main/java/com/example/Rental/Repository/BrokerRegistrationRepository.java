package com.example.Rental.Repository;

import com.example.Rental.Entity.BrokerRegistration;
import jdk.jfr.Registered;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BrokerRegistrationRepository extends JpaRepository<BrokerRegistration,Integer> {
    BrokerRegistration findByMobileno(String mobileno);
}
